﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.Enums
{
    public enum PortionNames
    {
        Kadeh,
        Shot,
        Sise,
        Bardak,
        Porsiyon,
        Paket,
        YemekKasigi,
        Dilim,
        Kase,
        Fileto,
        Adet,
        Gram
    }
}
