﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.Enums
{
    public enum MealTypes
    {
        Kahvalti = 1,
        OgleYemegi,
        AksamYemegi,
        Diger
    }
}
